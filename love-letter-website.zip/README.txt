LOVE LETTER WEBSITE

1. Open index.html in a browser to test it.
2. To share it online for free, upload these 3 files to a GitHub repository and enable GitHub Pages.
3. Edit the letter text inside script.js (variable: letterText).
