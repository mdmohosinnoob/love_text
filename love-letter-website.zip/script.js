const intro = document.getElementById("intro");
const terminal = document.getElementById("terminal");
const letter = document.getElementById("letter");
const code = document.getElementById("code");
const message = document.getElementById("message");
const confetti = document.getElementById("confetti");

const codeText = `const love = {
  status: "still yours",
  secret: true,
  message: "You are special to me ❤️"
};

if (love.secret) {
  reveal("Dear Love...");
}`;

const letterText =
  "I wanted to make something a little different for you. " +
  "So I hid these words inside a few lines of code. " +
  "No matter how simple this little page looks, the thought behind it is real. " +
  "Thank you for being someone who can make ordinary moments feel special. " +
  "I hope this small surprise makes you smile today. ❤️";

function typeText(el, text, speed, done) {
  let i = 0;
  el.textContent = "";
  const timer = setInterval(() => {
    el.textContent += text[i++];
    if (i >= text.length) {
      clearInterval(timer);
      if (done) done();
    }
  }, speed);
}

function makeConfetti() {
  confetti.classList.remove("hidden");
  confetti.innerHTML = "";
  for (let i = 0; i < 45; i++) {
    const p = document.createElement("i");
    p.className = "particle";
    p.style.left = Math.random() * 100 + "%";
    p.style.top = (-10 - Math.random() * 20) + "px";
    p.style.animationDelay = Math.random() * .8 + "s";
    p.style.transform = `scale(${.5 + Math.random()})`;
    confetti.appendChild(p);
  }
  setTimeout(() => confetti.classList.add("hidden"), 3500);
}

function start() {
  intro.classList.add("hidden");
  letter.classList.add("hidden");
  terminal.classList.remove("hidden");
  typeText(code, codeText, 28, () => {
    setTimeout(() => {
      terminal.classList.add("hidden");
      letter.classList.remove("hidden");
      typeText(message, letterText, 35);
      makeConfetti();
    }, 900);
  });
}

document.getElementById("openBtn").addEventListener("click", start);
document.getElementById("replayBtn").addEventListener("click", start);
